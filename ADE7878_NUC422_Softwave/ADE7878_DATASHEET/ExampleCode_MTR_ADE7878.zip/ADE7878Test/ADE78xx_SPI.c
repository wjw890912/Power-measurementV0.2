/************************************************************************************************

 Author        : CAC (China Applications Support Team)         

 Date          : October 2012

 File          : ADE7878_SPI.h

 Hardware      : ADE7878, ADuC7060

 Description   : Test with ADE7878
 			     Config ADE7878 to read phase A current rms, voltage rms, energy, period, in linecycle mode

*************************************************************************************************/
#include "includes.h"

//extern unsigned char szTxData[7];
extern unsigned char DummyRd;

/******************************************************************************
**  Abstract:   
**		short delay
**  Parameters:	
**		none  
**  Returns:
**		none
*******************************************************************************/
void SPIDelay(void)
{
	int i;
	for(i=0; i<20; i++);
}

/******************************************************************************
**  Abstract:   
**		write 4 bytes to ADE7878
**  Parameters:	
**		unsigned int address: register address 
**		long int sendtemp   : configuration value  
**  Returns:
**		none
*******************************************************************************/
void SPIWrite4Bytes(unsigned int address , long int sendtemp)
{
	char i;
	unsigned char szTxData[7];
	CLR_PIN00();
	szTxData[0] = 0x00; 	
	szTxData[1] = (char)(address>>8);
	szTxData[2] = (char)(address);
	szTxData[3] = (char)(sendtemp>>24);
	szTxData[4] = (char)(sendtemp>>16);
	szTxData[5] = (char)(sendtemp>>8);
	szTxData[6] = (char)(sendtemp);
	for(i=0;i<7;i++)
	{
		SPITX = szTxData[i];
		SPIDelay();
	}
	SET_PIN00(); 	
}

/******************************************************************************
**  Abstract:   
**		write 2 bytes to ADE7878
**  Parameters:	
**		unsigned int address: register address 
**		long int sendtemp   : configuration value  
**  Returns:
**		none
*******************************************************************************/
void SPIWrite2Bytes(unsigned int address , int sendtemp)
{
	char i;
	unsigned char szTxData[7];
	CLR_PIN00();
	szTxData[0] = 0x00; 	
	szTxData[1] = (char)(address>>8);
	szTxData[2] = (char)(address);
	szTxData[3] = (char)(sendtemp>>8);
	szTxData[4] = (char)(sendtemp);

	for(i=0;i<5;i++)
	{
		SPITX = szTxData[i];
		SPIDelay();
	}
	SET_PIN00(); 

}

/******************************************************************************
**  Abstract:   
**		write 1 byte to ADE7878
**  Parameters:	
**		unsigned int address: register address 
**		long int sendtemp   : configuration value  
**  Returns:
**		none
*******************************************************************************/
void SPIWrite1Byte(unsigned int address , char sendtemp)
{
	char i;
	unsigned char szTxData[7];
	CLR_PIN00();
	szTxData[0] = 0x00; 	
	szTxData[1] = (char)(address>>8);
	szTxData[2] = (char)(address);
	szTxData[3] = sendtemp;

	for(i=0;i<4;i++)
	{
		SPITX = szTxData[i];
		SPIDelay();
	}
	
	SET_PIN00(); 
}

/******************************************************************************
**  Abstract:   
**		read 4 bytes from ADE7878
**  Parameters:	
**		unsigned int address: register address 
**  Returns:
**		readout	            : read value
*******************************************************************************/
long int SPIRead4Bytes(unsigned int address)
{
	long int readout;
	unsigned char szTxData[7];
	char spireadbuf[4];
	char i;

	CLR_PIN00();
	szTxData[0] = 0x01; 	
	szTxData[1] = (char)(address>>8);
	szTxData[2] = (char)(address); 
	
	for(i=0;i<3;i++)
	{
		SPITX = szTxData[i];
		SPIDelay();
	}
	SPICON |= BIT12; // Flush Rx FIFO
	SPICON &= ~BIT12;

	DummyRd = SPIRX;
	for(i=0;i<4;i++)
	{
		SPITX = 0x00;
		SPIDelay();
		spireadbuf[i] = SPIRX;		
	}
		
	readout = (spireadbuf[0]<<24)+(spireadbuf[1]<<16)+(spireadbuf[2]<<8)+spireadbuf[3];

	SET_PIN00(); 	
	return(readout); 
}

/******************************************************************************
**  Abstract:   
**		read 2 bytes from ADE7878
**  Parameters:	
**		unsigned int address: register address 
**  Returns:
**		readout	            : read value
*******************************************************************************/
int SPIRead2Bytes(unsigned int address)
{
	int readout;
	unsigned char szTxData[7];
	char i;
	char spireadbuf[2];

	CLR_PIN00();
	szTxData[0] = 0x01; 	
	szTxData[1] = (char)(address>>8);
	szTxData[2] = (char)(address);
	
	for(i=0;i<3;i++)
	{
		SPITX = szTxData[i];
		SPIDelay();
	}

	SPICON |= BIT12; // Flush Rx FIFO
	SPICON &= ~BIT12;
	DummyRd = SPIRX;
	for(i=0;i<2;i++)
	{	
		SPITX = 0x00;
		SPIDelay();
		spireadbuf[i] = SPIRX;		
	}
		
	readout = (spireadbuf[0]<<8)+spireadbuf[1];

	SET_PIN00(); 	
	return(readout);
}

/******************************************************************************
**  Abstract:   
**		read 1 byte from ADE7878
**  Parameters:	
**		unsigned int address: register address 
**  Returns:
**		readout	            : read value
*******************************************************************************/
char SPIRead1Byte(unsigned int address)
{
	char readout;
	unsigned char szTxData[7];
	char i;

	CLR_PIN00();
	szTxData[0] = 0x01; 	
	szTxData[1] = (char)(address>>8);
	szTxData[2] = (char)(address); 
	
	for(i=0;i<3;i++)
	{
		SPITX = szTxData[i];
		SPIDelay();
	}
	SPICON |= BIT12; // Flush Rx FIFO
	SPICON &= ~BIT12;
	DummyRd = SPIRX;
	SPITX = 0x00;
	SPIDelay();
	readout = SPIRX;

	SET_PIN00();
	
	return(readout); 
}
