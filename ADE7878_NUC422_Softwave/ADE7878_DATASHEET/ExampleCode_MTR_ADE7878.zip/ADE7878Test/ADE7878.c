/************************************************************************************************

 Author        : CAC (China Applications Support Team)         

 Date          : October 2012

 File          : ADE7878_SPI.h

 Hardware      : ADE7878, ADuC7060

 Description   : Test with ADE7878
 			     Config ADE7878 to read phase A current rms, voltage rms, energy, period, in linecycle mode

*************************************************************************************************/
#include "includes.h"

/******************************************************************************
**  Abstract:   
**		RESET ADE7878	
**  Parameters:	
**		none  
**  Returns:
**		none
*******************************************************************************/
void ADE7878Reset(void)
{
	SET_PIN14();   //
	Delay(10);
	CLR_PIN14();   //
	Delay(10);		
	SET_PIN14();   //
	Delay(100);	       	
}
/******************************************************************************
**  Abstract:   
**		choose PSM0 Mode   PM1 = 0; PM0 = 1	
**  Parameters:	
**		none  
**  Returns:
**		none
*******************************************************************************/
void ADE7878PSM0(void)
{
	CLR_PIN15();  
	SET_PIN16();   //
	Delay(100);	   //wait for the ADE power up after PSM0 is chosen,	more than 40ms is needed 
}
/******************************************************************************
**  Abstract:   
**		choose SPI interface,   toggle SS three times
**  Parameters:	
**		none  
**  Returns:
**		none
*******************************************************************************/
void ADE7878SPICfg(void)
{
	SET_PIN00();
	SPIDelay();
	CLR_PIN00();	  //toggle once
	SPIDelay();
	SET_PIN00();
	SPIDelay();
	CLR_PIN00();	  //toggle twice
	SPIDelay();
	SET_PIN00();
	SPIDelay();
	CLR_PIN00();	  //triple triple
	SPIDelay();
	SET_PIN00();
	SPIDelay();

	SPIWrite1Byte(0xEC01, 0x00);	 //SPI is the active serial port, any write to CONFIG2 register locks the port

	//The 2nd way to choose SPI mode is to execute three SPI write operations 
	//to a location in the address space that is not allocated to a specific ADE78xx register
	/*
	SPIWrite1Byte(0xEBFF, 0x00);								 
	SPI_read_32(0xEBFF);
	SPIWrite1Byte(0xEBFF, 0x00);
	SPI_read_32(0xEBFF);
	SPIWrite1Byte(0xEBFF, 0x00);
	SPI_read_32(0xEBFF);
	*/
}
/******************************************************************************
**  Abstract:   
**		ADE7878 configuration
**  Parameters:	
**		none  
**  Returns:
**		none
*******************************************************************************/
void ADE7878Cfg(void)
{
	SPIWrite2Bytes(Gain,0x0000);				  //config the  Gain of the PGA , which is before the ADC of ADE7878
	SPIWrite2Bytes(CONFIG,0x0000);			  //
	SPIWrite2Bytes(HPFDIS,0x0000);			  //enabled high-pass filters
	
	SPIWrite4Bytes(AIGAIN,0x00000000);		  //calibration
	SPIWrite4Bytes(AVGAIN,0x00000000);
	SPIWrite4Bytes(BIGAIN,0x00000000);
	SPIWrite4Bytes(BVGAIN,0x00000000);
	SPIWrite4Bytes(CIGAIN,0x00000000);
	SPIWrite4Bytes(CVGAIN,0x00000000);
	SPIWrite4Bytes(NIGAIN,0x00000000);
 	SPIWrite4Bytes(AIRMSOS,0x00000000);
	SPIWrite4Bytes(AVRMSOS,0x00000000);
	SPIWrite4Bytes(BIRMSOS,0x00000000);
	SPIWrite4Bytes(BVRMSOS,0x00000000);
	SPIWrite4Bytes(CIRMSOS,0x00000000);
	SPIWrite4Bytes(CVRMSOS,0x00000000);
	SPIWrite4Bytes(NIRMSOS,0x00000000);
 	SPIWrite4Bytes(AWGAIN,0x00000000);
	SPIWrite4Bytes(AWATTOS,0x00000000);
	SPIWrite4Bytes(BWGAIN,0x00000000);
	SPIWrite4Bytes(BWATTOS,0x00000000);
	SPIWrite4Bytes(CWGAIN,0x00000000);
	SPIWrite4Bytes(CWATTOS,0x00000000);
	SPIWrite2Bytes(APHCAL,0x0000);
	SPIWrite2Bytes(BPHCAL,0x0000);
	SPIWrite2Bytes(CPHCAL,0x0000);

	SPIWrite2Bytes(CF1DEN,0x00A7);	  		  //configure the ENERGY-TO-FREQUENCY
	SPIWrite2Bytes(CF2DEN,0x00A7);
	SPIWrite2Bytes(CF3DEN,0x00A7);
	SPIWrite2Bytes(CFMODE,0x0E88);			  //CF1-total active power, disable; CF2-total reactvie power, disable; CF3- fundamental avtive power, disable

	SPIWrite2Bytes(ACCMODE,0x0000);
	SPIWrite2Bytes(COMPMODE,0x01FF);
	SPIWrite1Byte(MMODE,0x00);

	SPIWrite4Bytes(WTHR0,0x007BBE61);			  //PMAX = 33,516,139	  0.001WH/LSB	 //page 47 datasheet Rev. E										  
	SPIWrite4Bytes(WTHR1,0x00000017);
	SPIWrite4Bytes(VATHR0,0x007BBE61);		  //PMAX = 33,516,139
	SPIWrite4Bytes(VATHR1,0x00000017);
	SPIWrite4Bytes(VARTHR0,0x007BBE61);		  //PMAX = 33,516,139
	SPIWrite4Bytes(VARTHR1,0x00000017);

	
	SPIWrite1Byte(LCYCMODE,0x0F);				  //phase A is selected for zero cross
	SPIWrite2Bytes(LINECYC,0x0064);

	SPIWrite4Bytes(MASK0,0x00000020);			  //line cycle interrupt enable
	SPIWrite4Bytes(MASK1,0x00000000);   

}
