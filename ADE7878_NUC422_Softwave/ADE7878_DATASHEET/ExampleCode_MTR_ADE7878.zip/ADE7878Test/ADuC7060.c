/************************************************************************************************

 Author        : CAC (China Applications Support Team)         

 Date          : October 2012

 File          : ADE7878_SPI.h

 Hardware      : ADE7878, ADuC7060

 Description   : Test with ADE7878
 			     Config ADE7878 to read phase A current rms, voltage rms, energy, period, in linecycle mode

*************************************************************************************************/
#include "includes.h"

/******************************************************************************
**  Abstract:   
**		ADuC7060 initialization
**			SPI:	P0.0-SS, P0.1- SCL, P0.2-MISO, P0.3-MOSI  (P0.0 is GPIO)
**			GPIO:   P1.4-RESET, P1.5-PM1, P1.6-PM0
**			UART:	19200bps, 8-N-1, P1.0/P1.1
**			IRQ:    Enable XIRQ0 interrupt		
**  Parameters:	
**		none  
**  Returns:
**		none
*******************************************************************************/
void ADuC7060Init(void)
{	  
	POWKEY1 = 0x1;
	POWCON0 = 0x78;		   // Set core to max CPU speed of 10.24Mhz
	POWKEY2 = 0xF4;

	// Initilize GPIO
	GP1DAT  = BIT30 + BIT29 + BIT28 + BIT27 ;		// Configure P1.6 P1.3 P1.4 P1.5 as an output 			
	//uiTest = GP0CON0;
	//uiTest = GP0CON1;
	//GP0DAT = BIT16 + BIT24;
	GP1SET |= PIN_3;
	//GP1SET |= PIN_2;
	GP0SET = BIT16; 
	
	GP0DAT = BIT24;      //+BIT29
	GP0SET |= PIN_0;
	//GP0SET |= PIN_5;
	/**/

	// Initilize Timer 1 in Periodic mode with timeout period of 1 Second
	T1LD  = 0x8000;			// 32768 clock ticks
	T1CON = BIT6 + BIT7;	// Periodic mode, enable timer, 32768hz clock/1
	//IRQCONE = BIT1;			// Rising edge
	//IRQEN |= BIT4 + BIT13;			// Enable Timer 1 IRQ

	// Initialize the UART for 19200-8-N
	GP1CON = BIT0 + BIT4;  // Select UART functionality for P1.0/P1.1
	COMCON0 = BIT7;			// Enable access to COMDIV registers
	COMDIV0 = 0x11;			// Set baud rate to 19200.
	COMDIV1 = 0x00;
	//COMDIV2 = 0x31C + BIT11; // Enable fractional divider for more accurate baud rate setting
	COMCON0 = BIT0 + BIT1 + BIT2;

	// Configure P0.0, P0.1,P0.2 and P0.3 for SPI mode		
	GP0CON0 = BIT4 + BIT8 + BIT12; // Select SPI/I2C alternative function for P0[0...3]	   //BIT0 +   P00
	GP0KEY1 = 0x7;		   //Write to GP0KEY1
	GP0CON1	= 0x00;	   // Select SPI functionality for P0.0 to  P0.3
	GP0KEY2 = 0x13;		   //Write to GP0KEY2

	
	SPICON = BIT0 + BIT1   // Enable SPI + Enable SPI Master
		    + BIT6  // Clk pulses high at start of each bit + Initiate transfer on write to Tx FIFO					
			+ BIT2 + BIT3 	 //SPICPO = 1;	  //SPICPH = 1;
			//+ BIT14 + BIT15		
		    + BIT11;		   //Continuous transfer mode + Enable IRQ on 2 byte transfer   //	+ BIT9		
	SPIDIV  = 0x09;	   		// Select 101kHz clock rate = 0x31 0x3F
	IRQCONE = BIT1+BIT0;			// Rising edge of XIRQ0
	IRQEN |= BIT13; 		// Enable SPI + XIRQ0 interrupt	    + BIT13
}

/******************************************************************************
**  Abstract:   
**		long delay
**  Parameters:	
**		times: delay times  
**  Returns:
**		none
*******************************************************************************/
void Delay (int times)
{
	int i,j;
	for(i=0; i<times; i++)
		for(j=0; j<10000; j++)
		;	
}

/******************************************************************************
**  Abstract:   
**		uart print int data
**  Parameters:	
**		sendtata: data to be sent  
**  Returns:
**		none
*******************************************************************************/
void PutInt(int senddata)
{
	char sendtemp[7];
	char i;
	sendtemp[0] = (char)(senddata>>20)&0x0F;
	sendtemp[1] = (char)(senddata>>16)&0x0F;
	sendtemp[2] = (char)(senddata>>12)&0x0F;
	sendtemp[3] = (char)(senddata>>8)&0x0F;
	sendtemp[4] = (char)(senddata>>4)&0x0F;
	sendtemp[5] = (char)(senddata)&0x0F;
	for(i=0;i<6;i++)
	{
		/**/
		if(sendtemp[i]<10)
			COMTX = (sendtemp[i]+0x30);
		else if(sendtemp[i]<16)
			COMTX = (sendtemp[i]+0x37);
		
		//COMTX = sendtemp[i];
		while ((COMSTA0 & 0x40) == 0x00)	  // Wait for Tx buffer empty bit to be set
  		 {
  		 }
	}
}

/******************************************************************************
**  Abstract:   
**		uart print char data
**  Parameters:	
**		ch: data to be sent  
**  Returns:
**		none
*******************************************************************************/
void PutChar(unsigned char ch)				   //output a char via UART
{          
	COMTX = ch;				 				   //COMTX is an 8-bit transmit register.
	while ((COMSTA0 & 0x40) == 0x00){}
}

/******************************************************************************
**  Abstract:   
**		uart print string
**  Parameters:	
**		str: string to be sent  
**  Returns:
**		none
*******************************************************************************/
void PutString(char *str)						//output a string via UART
{          
	unsigned int len=0,i;
	while ((str[len] >31)||(str[len]=='\n'))
		len++;
	for (i=0;i<len;i++)
	{
	  PutChar(str[i]);
	}
}

/******************************************************************************
**  Abstract:   
**		uart print read value
**  Parameters:	
**		str: string to be sent
**      senddata: data to be sent
**  Returns:
**		none
*******************************************************************************/
void PrintReadcode(char *str, int senddata)
{
	PutString(str);
	PutInt(senddata);	
}
