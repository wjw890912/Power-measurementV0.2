//***************************************************************************/
#define PIN_0  	    ((0x1<<16)<<0)
#define PIN_1  	    ((0x1<<16)<<1)
#define PIN_2  	    ((0x1<<16)<<2)
#define PIN_3  	    ((0x1<<16)<<3)
#define PIN_4  	    ((0x1<<16)<<4)
#define PIN_5  	    ((0x1<<16)<<5)
#define PIN_6  	    ((0x1<<16)<<6)
#define PIN_7  	    ((0x1<<16)<<7)

#define PIN_0_CON  	((0x1<<24)<<0)
#define PIN_1_CON  	((0x1<<24)<<1)
#define PIN_2_CON  	((0x1<<24)<<2)
#define PIN_3_CON  	((0x1<<24)<<3)
#define PIN_4_CON  	((0x1<<24)<<4)
#define PIN_5_CON  	((0x1<<24)<<5)
#define PIN_6_CON  	((0x1<<24)<<6)
#define PIN_7_CON  	(0x80000000)

// Bit Definitions
#define BIT0  0x01
#define BIT1  0x02
#define BIT2  0x04
#define BIT3  0x08
#define BIT4  0x10
#define BIT5  0x20
#define BIT6  0x40
#define BIT7  0x80
#define BIT8  0x100
#define BIT9  0x200
#define BIT10 0x400
#define BIT11 0x800
#define BIT12 0x1000
#define BIT13 0x2000
#define BIT14 0x4000
#define BIT15 0x8000
#define BIT16 0x10000
#define BIT20 0x100000
#define BIT21 0x200000
#define BIT22 0x400000
#define BIT24 0x1000000
#define BIT26 0x4000000
#define BIT27 0x8000000
#define BIT28 0x10000000
#define BIT29 0x20000000
#define BIT30 0x40000000


