/************************************************************************************************

 Author        : CAC (China Applications Support Team)         

 Date          : October 2012

 File          : ADE7878_SPI.h

 Hardware      : ADE7878, ADuC7060

 Description   : Test with ADE7878
 			     Config ADE7878 to read phase A current rms, voltage rms, energy, period, in linecycle mode

*************************************************************************************************/

#include "includes.h"
	
//unsigned char szTxData[7];	                    // Array to send to Slave
unsigned char DummyRd = 0;
unsigned int  IRQStautsRead0 = 0;
unsigned int  IRQStautsRead1 = 0;
unsigned char IRQFlag = 0;

int  IRMSRead[20];					  
char IRMSIndex = 0;
int  VRMSRead[20];					  
char VRMSIndex = 0;

int PhaseAEnergy = 0;		 
int PhaseAIRMS   = 0;
int PhaseAVRMS   = 0;
int PhaseAPeroid = 0;
int PhaseAAngle  = 0;
/************************************************************************************************/


int main(void)
{
	ADuC7060Init();		          //intial ADuC7060
	ADE7878Reset();				  //Reset ADE7878
	ADE7878PSM0();			      //setting ADE7878 to normal power mode
	ADE7878SPICfg();		      //choose SPI mode

	//********clear the IRQ1 interrupt, by writing the STATUS1 register**********************
	//*The ADE7878 signals the end of the transition period by triggering the IRQ1 interrupt pin low 
	//*and setting Bit 15 (RSTDONE) in the STATUS1 register to 1. 
	//*This bit is 0 during the transition period and becomes 1 when the transition ends.
	//***************************************************************************************
	IRQStautsRead0 = SPIRead4Bytes(STATUS1);
	SPIWrite4Bytes(STATUS1,IRQStautsRead0);
	if((IRQStautsRead0&BIT15)==BIT15)
	{
		PutString("ADE7878 OK\n");
	}	

	ADE7878Cfg();				  //config ADE7878
	
	IRQEN |= BIT13;			      //ADuC7060 interrupt enable 
	SPIWrite2Bytes(Run,0x0001);	  //run ADE7878 DSP
	Delay(100);					  //Delay to wait the rms settling

	while(1)
	{
		if (1==IRQFlag)  		  //waiting for a interrupt
		{
			IRQFlag = 0;		  
			//******************************************************************
			//*using the interrupt
			//*for only one interrupt is chosen, the source of the interrupt is not determined
			//******************************************************************
			IRQStautsRead0 = SPIRead4Bytes(STATUS0);		 //read the interrupt status
			SPIDelay();			
			SPIWrite4Bytes(STATUS0,IRQStautsRead0);        //write the same STATUSx content back to clear the flag and reset the IRQ line
			SPIDelay();  

			//******************************************************************
			//*line cycle interrupt to read the energy and rms
			//******************************************************************
			PhaseAEnergy = SPIRead4Bytes(AWATTHR);		 
			PhaseAIRMS   = SPIRead4Bytes(AIRMS);
			PhaseAVRMS   = SPIRead4Bytes(AVRMS);
			PhaseAPeroid = SPIRead2Bytes(PERIOD);
			//PhaseAAngle  = SPIRead2Bytes(ANGLE0);

			//******************************************************************
			//*send the reading via UART
			//******************************************************************

			PrintReadcode("IRMS:",PhaseAIRMS);
			PrintReadcode("  VRMS:",PhaseAVRMS);
			PrintReadcode("  Energy:",PhaseAEnergy);
			PutChar(0x0A);
			SPIDelay(); 
			//IRQEN |= BIT13;				
		}			
	}
}

void IRQ_Handler(void) __irq  
{
    unsigned long IRQSTATUS = 0;
   	unsigned int SPIMSTATUS = 0;
	unsigned char Underflow = 0;

	IRQSTATUS = IRQSTA;	   // Read off IRQSTA register

	if ((IRQSTATUS & BIT4) == BIT4)	//Timer 1 interrupt source
	{
		 //GP1DAT ^= BIT22;	// Toggle LED on Evaluation board (P1.6)
		 T1CLRI = 0x55;		// Clear the currently active Timer0 Irq
	}

	if ((IRQSTATUS & BIT13) == BIT13)	//External Interrupt0 source
	{
		 //ucToggleRate++;
		 IRQCLRE = BIT13;			   // Clear External Interrupt 0
		 IRQFlag = 1;
	}
	
	if ((IRQSTATUS & BIT12) == BIT12)	//If SPI Master interrupt source
	{
	   SPIMSTATUS = SPISTA;
	   if ((SPIMSTATUS & BIT4) == BIT4) // SPI Tx underflow
	   {
			Underflow = 1;
	   }
	   if ((SPIMSTATUS & BIT5) == BIT5) // If SPI Master Tx IRQ
	   {
			//utTest++;
						
	   }
	   if ((SPIMSTATUS & BIT6) == BIT6) // If SPI Master Rx IRQ
	   {		
			//ucTest++;
	   }
	}
}


