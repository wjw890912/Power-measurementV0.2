/************************************************************************************************

 Author        : CAC (China Applications Support Team)         

 Date          : October 2012

 File          : ADE7953_SPI.h

 Hardware      : ADE7953, ADuC7060

 Description   : Test with ADE7953
 			     Config ADE7953 to read phase A current rms, voltage rms, energy, period, in linecycle mode

*************************************************************************************************/

void     SPIDelay(void);
void     SPIWrite4Bytes(unsigned int address , long int sendtemp);
void     SPIWrite2Bytes(unsigned int address , int sendtemp);
void     SPIWrite1Byte(unsigned int address , char sendtemp);
long int SPIRead4Bytes(unsigned int address);
int      SPIRead2Bytes(unsigned int address);
char     SPIRead1Byte (unsigned int address);

