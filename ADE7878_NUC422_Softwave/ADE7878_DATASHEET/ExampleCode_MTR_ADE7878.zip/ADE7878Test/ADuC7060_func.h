/************************************************************************************************

 Author        : CAC (China Applications Support Team)         

 Date          : October 2012

 File          : ADE7878_SPI.h

 Hardware      : ADE7878, ADuC7060

 Description   : Test with ADE7878
 			     Config ADE7878 to read phase A current rms, voltage rms, energy, period, in linecycle mode

*************************************************************************************************/
#define SET_PIN14()   GP1DAT = (GP1DAT|BIT20);   
#define CLR_PIN14()   GP1DAT = (GP1DAT&(~BIT20));
#define CLR_PIN15()   GP1DAT = (GP1DAT&(~BIT21));
#define SET_PIN16()	  GP1DAT = (GP1DAT|BIT22);   
#define SET_PIN00()   GP0DAT = (GP0DAT|BIT16);   
#define CLR_PIN00()   GP0DAT = (GP0DAT&(~BIT16));

void Delay (int times);
void ADuC7060Init(void);
void PutInt(int senddata);
void PutChar(unsigned char ch);
void PutString(char *str);
void PrintReadcode(char *str, int senddata);
