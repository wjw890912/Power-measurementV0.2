/************************************************************************************************

 Author        : CAC (China Applications Support Team)         

 Date          : October 2012

 File          : ADE7878_SPI.h

 Hardware      : ADE7878, ADuC7060

 Description   : Test with ADE7878
 			     Config ADE7878 to read phase A current rms, voltage rms, energy, period, in linecycle mode

*************************************************************************************************/
#include <aduc7060.h>
#include "ADuc7060_PinCon.h"
#include "ADE7878.h"
#include "ADE78xx_SPI.h"
#include <stdio.h>
#include <string.h>
#include "aduc7060_func.h"
